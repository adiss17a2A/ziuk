module.exports = {
    // Array of user IDs allowed to use Troll commands
    ALLOWED_USERS: [
        "876151017329291284",
        "905548618252054578"
    ],
};