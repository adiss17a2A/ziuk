const { ALLOWED_USERS } = require('../config');

function checkPermissions(userId) {
    return ALLOWED_USERS.includes(userId);
}

module.exports = {
    checkPermissions,
};
