const { SlashCommandBuilder } = require('discord.js');
const { checkPermissions } = require('../../utils/permissions');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tunkick')
        .setDescription('hahahaha')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to stop auto-kicking')
                .setRequired(true)),

    async execute(interaction) {
        // Check if user has permission to use this command
        if (!checkPermissions(interaction.user.id)) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command!',
                ephemeral: true
            });
        }

        const target = interaction.options.getUser('target');

        // Remove user from kick list
        interaction.client.kickedUsers.delete(target.id);

        await interaction.reply({
            content: `✅ User ${target.tag} will no longer be automatically kicked from voice channels!`,
            ephemeral: true
        });
    },
};