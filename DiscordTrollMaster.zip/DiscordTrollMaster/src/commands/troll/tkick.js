const { SlashCommandBuilder } = require('discord.js');
const { checkPermissions } = require('../../utils/permissions');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tkick')
        .setDescription('hahahaha')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to auto-kick')
                .setRequired(true)),

    async execute(interaction) {
        // Check if user has permission to use this command
        if (!checkPermissions(interaction.user.id)) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command!',
                ephemeral: true
            });
        }

        const target = interaction.options.getUser('target');
        const member = interaction.guild.members.cache.get(target.id);

        // Add user to kick list
        interaction.client.kickedUsers.set(target.id, true);

        // If user is already in a voice channel, kick them immediately
        if (member && member.voice.channel) {
            try {
                await member.voice.disconnect();
                console.log(`[IMMEDIATE KICK] Uživatel ${target.tag} byl okamžitě vyhozen z hlasového kanálu`);
            } catch (error) {
                console.error(`[ERROR] Nepodařilo se okamžitě vyhodit uživatele ${target.tag}:`, error);
                // Pokus o alternativní způsob vyhození
                try {
                    await member.voice.setChannel(null);
                    console.log(`[SUCCESS] Uživatel ${target.tag} byl vyhozen alternativním způsobem`);
                } catch (altError) {
                    console.error(`[ERROR] Alternativní způsob vyhození selhal:`, altError);
                }
            }
        }

        await interaction.reply({
            content: `🎯 User ${target.tag} will now be automatically kicked from voice channels!`,
            ephemeral: true
        });
    },
};