const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setupverify')
        .setDescription('Nastaví verifikaci pomocí příkazu')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role, která bude přidělena po verifikaci')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('success_message')
                .setDescription('Zpráva při úspěšné verifikaci')
                .setRequired(false)),

    async execute(interaction) {
        const role = interaction.options.getRole('role');
        const successMessage = interaction.options.getString('success_message') || '✅ Byli jste úspěšně verifikováni!';

        // Uložíme nastavení do cache
        interaction.client.verifyRoles.set('command_verify', {
            roleId: role.id,
            successMessage: successMessage
        });

        const setupEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Nastavení Command Verify')
            .setDescription(`Verifikace příkazem byla nastavena!\n\nUživatelé se nyní mohou verifikovat pomocí příkazu \`/verify\`\n\nRole: ${role.name}\nZpráva: ${successMessage}`)
            .setFooter({ text: 'Tip: Uživatelé mohou použít /verify pro verifikaci' });

        await interaction.reply({
            embeds: [setupEmbed],
            ephemeral: true
        });
    },
};
