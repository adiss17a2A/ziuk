const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('buttonverify')
        .setDescription('Vytvoří verifikační tlačítko')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role, která bude přidělena po verifikaci')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Název pro verifikační embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Popis pro verifikační embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('button_text')
                .setDescription('Text na verifikačním tlačítku')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('color')
                .setDescription('Barva embedu (např. #00ff00, RED, BLUE)')
                .setRequired(false)),

    async execute(interaction) {
        const role = interaction.options.getRole('role');
        const title = interaction.options.getString('title') || '✅ Verifikace';
        const description = interaction.options.getString('description') || 'Klikněte na tlačítko níže pro získání přístupu na server';
        const buttonText = interaction.options.getString('button_text') || 'Verify';
        const color = interaction.options.getString('color') || '#00ff00';

        const verifyEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title)
            .setDescription(description)
            .setFooter({ text: `Verifikační role: ${role.name}` });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('verify_button')
                    .setLabel(buttonText)
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅')
            );

        // Uložíme ID role do cache pro pozdější použití
        interaction.client.verifyRoles = interaction.client.verifyRoles || new Map();
        interaction.client.verifyRoles.set('verify_button', role.id);

        await interaction.channel.send({
            embeds: [verifyEmbed],
            components: [row]
        });

        await interaction.reply({
            content: `✅ Verifikační systém byl úspěšně nastaven!\n📑 Role: ${role.name}\n🎨 Barva: ${color}\n📌 Název: ${title}`,
            ephemeral: true
        });
    },
};