const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verify')
        .setDescription('Verifikuje vás na serveru'),

    async execute(interaction) {
        const verifySettings = interaction.client.verifyRoles.get('command_verify');
        
        if (!verifySettings) {
            return interaction.reply({
                content: '❌ Verifikace příkazem není na tomto serveru nastavena.',
                ephemeral: true
            });
        }

        const role = interaction.guild.roles.cache.get(verifySettings.roleId);
        if (!role) {
            return interaction.reply({
                content: '❌ Verifikační role neexistuje. Kontaktujte administrátora.',
                ephemeral: true
            });
        }

        try {
            await interaction.member.roles.add(role);
            await interaction.reply({
                content: verifySettings.successMessage,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error while verifying user:', error);
            await interaction.reply({
                content: '❌ Nastala chyba při verifikaci. Zkuste to prosím znovu nebo kontaktujte administrátora.',
                ephemeral: true
            });
        }
    },
};
