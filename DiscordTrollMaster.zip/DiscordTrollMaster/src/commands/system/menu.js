const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { checkPermissions } = require('../../utils/permissions');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('menu')
        .setDescription('Zobrazí menu s dostupnými akcemi'),

    async execute(interaction) {
        // Vytvoření embed zprávy pro menu
        const menuEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🎮 Menu')
            .setDescription('Vyberte kategorii příkazů:');

        // Vytvoření select menu pro kategorie
        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('category_select')
                    .setPlaceholder('👉 Vyberte kategorii příkazů')
                    .addOptions([
                        {
                            label: 'Troll Příkazy',
                            description: 'Příkazy pro automatické vyhazování',
                            value: 'troll_category',
                            emoji: '😈',
                        },
                        {
                            label: 'Verify',
                            description: 'Verifikační systémy',
                            value: 'verify_category',
                            emoji: '✅',
                        },
                    ]),
            );

        // Odeslání menu
        await interaction.reply({
            embeds: [menuEmbed],
            components: [row],
            ephemeral: true
        });
    },
};