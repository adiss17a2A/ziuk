const { REST, Routes } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
require('dotenv').config();

const commands = [];
// Grab all the command folders from the commands directory
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
    // Grab all the command files from the commands directory
    const commandsPath = path.join(foldersPath, folder);
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    // Grab the SlashCommandBuilder#toJSON() output of each command's data for deployment
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ('data' in command && 'execute' in command) {
            commands.push(command.data.toJSON());
        } else {
            console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
        }
    }
}

// Construct and prepare an instance of the REST module
const rest = new REST().setToken(process.env.DISCORD_TOKEN);

// Function to deploy commands to a specific guild
async function deployCommands(guildId) {
    try {
        console.log(`Started refreshing ${commands.length} application (/) commands for guild ${guildId}.`);

        // The put method is used to fully refresh all commands in the guild with the current set
        const data = await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, guildId),
            { body: commands },
        );

        console.log(`Successfully reloaded ${data.length} application (/) commands for guild ${guildId}.`);
    } catch (error) {
        console.error('Error:', error);
    }
}

// If GUILD_ID is provided, deploy to specific guild, otherwise deploy globally
if (process.env.GUILD_ID) {
    // You can add multiple guild IDs here by splitting them with commas
    const guildIds = process.env.GUILD_ID.split(',');
    for (const guildId of guildIds) {
        deployCommands(guildId.trim());
    }
} else {
    // Deploy globally (this can take up to an hour to propagate)
    (async () => {
        try {
            console.log(`Started refreshing ${commands.length} application (/) commands globally.`);

            const data = await rest.put(
                Routes.applicationCommands(process.env.CLIENT_ID),
                { body: commands },
            );

            console.log(`Successfully reloaded ${data.length} application (/) commands globally.`);
        } catch (error) {
            console.error('Error:', error);
        }
    })();
}