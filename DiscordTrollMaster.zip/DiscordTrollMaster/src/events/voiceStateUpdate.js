module.exports = {
    name: 'voiceStateUpdate',
    async execute(oldState, newState) {
        try {
            // Kontrola, zda je uživatel v kickedUsers
            if (newState.client.kickedUsers.has(newState.member.id)) {
                // Pokud je uživatel v hlasovém kanálu, vyhodit ho
                if (newState.member.voice.channel) {
                    console.log(`[KICK] Vyhazuji uživatele ${newState.member.user.tag} z kanálu ${newState.member.voice.channel.name}`);

                    try {
                        await newState.member.voice.disconnect();
                        console.log(`[SUCCESS] Uživatel ${newState.member.user.tag} byl vyhozen z hlasového kanálu`);
                    } catch (disconnectError) {
                        console.error(`[ERROR] Nepodařilo se vyhodit uživatele ${newState.member.user.tag}:`, disconnectError);
                        // Pokus o alternativní způsob vyhození
                        try {
                            await newState.setChannel(null);
                            console.log(`[SUCCESS] Uživatel ${newState.member.user.tag} byl vyhozen alternativním způsobem`);
                        } catch (altError) {
                            console.error(`[ERROR] Alternativní způsob vyhození selhal:`, altError);
                        }
                    }
                }
            }
        } catch (error) {
            console.error(`[ERROR] Chyba při zpracování voice state update pro ${newState.member?.user?.tag || 'neznámý uživatel'}:`, error);
        }
    },
};