const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { checkPermissions } = require('./utils/permissions');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
    ]
});

// Collections to store commands and kicked users
client.commands = new Collection();
client.kickedUsers = new Collection();
client.verifyRoles = new Collection();//Added for verify role storage

// Load commands
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        const filePath = path.join(folderPath, file);
        const command = require(filePath);
        client.commands.set(command.data.name, command);
    }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = require(filePath);
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
    } else {
        client.on(event.name, (...args) => event.execute(...args));
    }
}

// Handle interactions
client.on('interactionCreate', async interaction => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'There was an error executing this command!',
                ephemeral: true
            });
        }
    }
    // Handle select menu interactions
    else if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'category_select') {
            // Handle Troll category
            if (interaction.values[0] === 'troll_category') {
                // Kontrola oprávnění pro Troll kategorii
                if (!checkPermissions(interaction.user.id)) {
                    await interaction.reply({
                        content: '❌ Nemáte oprávnění pro zobrazení této kategorie příkazů!\nPouze vyvolení vládci chaosu mohou ovládat tuto moc! 😈',
                        ephemeral: true
                    });
                    return;
                }

                // Vytvoření tlačítek pro příkazy
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('select_tkick_target')
                            .setLabel('Auto-Kick')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('🎯'),
                        new ButtonBuilder()
                            .setCustomId('select_tunkick_target')
                            .setLabel('UnKick')
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('✅')
                    );

                const commandsEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('😈 Troll Příkazy')
                    .setDescription('Vyberte příkaz, který chcete použít:');

                await interaction.reply({
                    embeds: [commandsEmbed],
                    components: [row],
                    ephemeral: true
                });
            }
            // Handle Verify category
            else if (interaction.values[0] === 'verify_category') {
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('setup_button_verify')
                            .setLabel('Verify Tlačítkem')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji('🔘'),
                        new ButtonBuilder()
                            .setCustomId('setup_command_verify')
                            .setLabel('Verify Příkazem')
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji('💬')
                    );

                const verifyEmbed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Verify Systémy')
                    .setDescription('Vyberte typ verifikace, který chcete nastavit:');

                await interaction.reply({
                    embeds: [verifyEmbed],
                    components: [row],
                    ephemeral: true
                });
            }
        }
        // Handle user selection
        else if (interaction.customId === 'select_user_tkick' || interaction.customId === 'select_user_tunkick') {
            const userId = interaction.values[0];
            const command = interaction.customId === 'select_user_tkick' ? 'tkick' : 'tunkick';

            // Execute the command
            const commandObj = client.commands.get(command);
            if (commandObj) {
                try {
                    // Get the member from the guild
                    const member = interaction.guild.members.cache.get(userId);
                    if (!member) {
                        throw new Error('Uživatel nebyl nalezen.');
                    }

                    // Create a proper interaction object with all required properties
                    const fakeInteraction = {
                        ...interaction,
                        commandName: command,
                        options: {
                            getUser: () => member.user
                        },
                        client: interaction.client,
                        guild: interaction.guild,
                        channel: interaction.channel,
                        member: interaction.member,
                        user: interaction.user,
                        reply: interaction.reply.bind(interaction)
                    };

                    await commandObj.execute(fakeInteraction);
                } catch (error) {
                    console.error('Error executing command:', error);
                    await interaction.reply({
                        content: '❌ Nastala chyba při provádění příkazu! Zkuste to prosím znovu.',
                        ephemeral: true
                    });
                }
            }
        }
    }
    // Handle button interactions
    else if (interaction.isButton()) {
        // Kontrola oprávnění
        if (!checkPermissions(interaction.user.id)) {
            await interaction.reply({
                content: '❌ Nemáte oprávnění pro použití těchto příkazů!\nPouze vyvolení vládci chaosu mohou ovládat tuto moc! 😈',
                ephemeral: true
            });
            return;
        }

        try {
            if (interaction.customId === 'select_tkick_target' || interaction.customId === 'select_tunkick_target') {
                // Získat seznam členů serveru
                const members = await interaction.guild.members.fetch();
                const nonBotMembers = members.filter(member => !member.user.bot);

                // Pro tkick zobrazit pouze uživatele, kteří nejsou v kickedUsers
                // Pro tunkick zobrazit pouze uživatele, kteří jsou v kickedUsers
                const filteredMembers = interaction.customId === 'select_tkick_target'
                    ? nonBotMembers.filter(member => !client.kickedUsers.has(member.id))
                    : nonBotMembers.filter(member => client.kickedUsers.has(member.id));

                // Vytvořit select menu pro uživatele
                const row = new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId(interaction.customId === 'select_tkick_target' ? 'select_user_tkick' : 'select_user_tunkick')
                            .setPlaceholder('👉 Vyberte uživatele')
                            .addOptions(
                                filteredMembers.map(member => ({
                                    label: member.user.tag,
                                    value: member.id,
                                    emoji: '👤'
                                }))
                            )
                    );

                const listEmbed = new EmbedBuilder()
                    .setColor(interaction.customId === 'select_tkick_target' ? '#ff0000' : '#00ff00')
                    .setTitle(interaction.customId === 'select_tkick_target' ? '🎯 Vyberte uživatele pro Auto-Kick' : '✅ Vyberte uživatele pro UnKick')
                    .setDescription(
                        filteredMembers.size > 0
                            ? 'Vyberte uživatele ze seznamu níže:'
                            : (interaction.customId === 'select_tkick_target'
                                ? '😅 Všichni uživatelé jsou již na seznamu pro auto-kick!'
                                : '😅 Nikdo není na seznamu pro auto-kick!')
                    );

                // Pokud jsou nějací uživatelé k dispozici, zobrazit select menu
                if (filteredMembers.size > 0) {
                    await interaction.reply({
                        embeds: [listEmbed],
                        components: [row],
                        ephemeral: true
                    });
                } else {
                    await interaction.reply({
                        embeds: [listEmbed],
                        ephemeral: true
                    });
                }
            }
            // Handle verify button click
            else if (interaction.customId === 'verify_button') {
                try {
                    const roleId = interaction.client.verifyRoles.get('verify_button');
                    if (!roleId) {
                        await interaction.reply({
                            content: '❌ Verifikační role nebyla nalezena. Kontaktujte administrátora.',
                            ephemeral: true
                        });
                        return;
                    }

                    const role = interaction.guild.roles.cache.get(roleId);
                    if (!role) {
                        await interaction.reply({
                            content: '❌ Role neexistuje. Kontaktujte administrátora.',
                            ephemeral: true
                        });
                        return;
                    }

                    await interaction.member.roles.add(role);
                    await interaction.reply({
                        content: '✅ Byli jste úspěšně verifikováni!',
                        ephemeral: true
                    });
                } catch (error) {
                    console.error('Error handling verify button:', error);
                    await interaction.reply({
                        content: '❌ Nastala chyba při verifikaci. Zkuste to prosím znovu.',
                        ephemeral: true
                    });
                }
            }
            // Handle verify setup buttons
            else if (interaction.customId === 'setup_button_verify') {
                const modal = new ModalBuilder()
                    .setCustomId('button_verify_modal')
                    .setTitle('Nastavení Button Verify');

                const roleInput = new TextInputBuilder()
                    .setCustomId('role_id')
                    .setLabel('ID role pro verifikaci')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Zkopírujte ID role')
                    .setRequired(true);

                const titleInput = new TextInputBuilder()
                    .setCustomId('title')
                    .setLabel('Název embedu')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('✅ Verifikace')
                    .setRequired(false);

                const descriptionInput = new TextInputBuilder()
                    .setCustomId('description')
                    .setLabel('Popis v embedu')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('Klikněte na tlačítko níže pro získání přístupu na server')
                    .setRequired(false);

                const buttonTextInput = new TextInputBuilder()
                    .setCustomId('button_text')
                    .setLabel('Text na tlačítku')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Verify')
                    .setRequired(false);

                const colorInput = new TextInputBuilder()
                    .setCustomId('color')
                    .setLabel('Barva embedu (HEX nebo název)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('#00ff00 nebo GREEN')
                    .setRequired(false);

                const firstRow = new ActionRowBuilder().addComponents(roleInput);
                const secondRow = new ActionRowBuilder().addComponents(titleInput);
                const thirdRow = new ActionRowBuilder().addComponents(descriptionInput);
                const fourthRow = new ActionRowBuilder().addComponents(buttonTextInput);
                const fifthRow = new ActionRowBuilder().addComponents(colorInput);

                modal.addComponents(firstRow, secondRow, thirdRow, fourthRow, fifthRow);

                await interaction.showModal(modal);
            } else if (interaction.customId === 'setup_command_verify') {
                const modal = new ModalBuilder()
                    .setCustomId('command_verify_modal')
                    .setTitle('Nastavení Command Verify');

                const roleInput = new TextInputBuilder()
                    .setCustomId('role_id')
                    .setLabel('ID role pro verifikaci')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Zkopírujte ID role')
                    .setRequired(true);

                const successMessageInput = new TextInputBuilder()
                    .setCustomId('success_message')
                    .setLabel('Zpráva při úspěšné verifikaci')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('✅ Byli jste úspěšně verifikováni!')
                    .setRequired(false);

                const firstRow = new ActionRowBuilder().addComponents(roleInput);
                const secondRow = new ActionRowBuilder().addComponents(successMessageInput);

                modal.addComponents(firstRow, secondRow);

                await interaction.showModal(modal);
            }

        } catch (error) {
            console.error('Error handling button interaction:', error);
            await interaction.reply({
                content: 'Nastala chyba při zpracování požadavku!',
                ephemeral: true
            });
        }
    }
});

client.on('interactionCreate', async interaction => {
    if (interaction.isModalSubmit()) {
        if (interaction.customId === 'button_verify_modal') {
            try {
                const roleId = interaction.fields.getTextInputValue('role_id');
                const title = interaction.fields.getTextInputValue('title') || '✅ Verifikace';
                const description = interaction.fields.getTextInputValue('description') || 'Klikněte na tlačítko níže pro získání přístupu na server';
                const buttonText = interaction.fields.getTextInputValue('button_text') || 'Verify';
                const color = interaction.fields.getTextInputValue('color') || '#00ff00';

                const role = interaction.guild.roles.cache.get(roleId);
                if (!role) {
                    return interaction.reply({
                        content: '❌ Zadané ID role není platné nebo role neexistuje.',
                        ephemeral: true
                    });
                }

                const verifyEmbed = new EmbedBuilder()
                    .setColor(color)
                    .setTitle(title)
                    .setDescription(description)
                    .setFooter({ text: `Verifikační role: ${role.name}` });

                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('verify_button')
                            .setLabel(buttonText)
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('✅')
                    );

                // Uložíme ID role do cache pro pozdější použití
                interaction.client.verifyRoles.set('verify_button', roleId);

                await interaction.channel.send({
                    embeds: [verifyEmbed],
                    components: [row]
                });

                await interaction.reply({
                    content: `✅ Verifikační systém byl úspěšně nastaven!\n📑 Role: ${role.name}\n🎨 Barva: ${color}\n📌 Název: ${title}`,
                    ephemeral: true
                });
            } catch (error) {
                console.error('Error setting up button verify:', error);
                await interaction.reply({
                    content: '❌ Nastala chyba při nastavování verifikace. Zkontrolujte zadané hodnoty a zkuste to znovu.',
                    ephemeral: true
                });
            }
        } else if (interaction.customId === 'command_verify_modal') {
            try {
                const roleId = interaction.fields.getTextInputValue('role_id');
                const successMessage = interaction.fields.getTextInputValue('success_message') || '✅ Byli jste úspěšně verifikováni!';

                const role = interaction.guild.roles.cache.get(roleId);
                if (!role) {
                    return interaction.reply({
                        content: '❌ Zadané ID role není platné nebo role neexistuje.',
                        ephemeral: true
                    });
                }

                // Uložíme nastavení do cache
                interaction.client.verifyRoles.set('command_verify', {
                    roleId: roleId,
                    successMessage: successMessage
                });

                const setupEmbed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Nastavení Command Verify')
                    .setDescription(`Verifikace příkazem byla nastavena!\n\nUživatelé se nyní mohou verifikovat pomocí příkazu \`/verify\`\n\nRole: ${role.name}\nZpráva: ${successMessage}`)
                    .setFooter({ text: 'Tip: Uživatelé mohou použít /verify pro verifikaci' });

                await interaction.reply({
                    embeds: [setupEmbed],
                    ephemeral: true
                });
            } catch (error) {
                console.error('Error setting up command verify:', error);
                await interaction.reply({
                    content: '❌ Nastala chyba při nastavování verifikace. Zkontrolujte zadané hodnoty a zkuste to znovu.',
                    ephemeral: true
                });
            }
        }
    }
});

// Login bot
client.login(process.env.DISCORD_TOKEN);